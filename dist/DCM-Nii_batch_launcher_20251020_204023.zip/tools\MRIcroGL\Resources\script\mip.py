import gl
gl.resetdefaults()
gl.loadimage('chris_MRA')
#load Maximum Intensity Projection Shader
gl.shadername('MIP')
